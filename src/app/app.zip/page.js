import Providers from "./providers";
import ToastConfig from "../toast.config";

export default function Root({ children }) {
  return (
    <>
      <Providers>{children}</Providers>
      <ToastConfig />
    </>
  );
}
