import FeaturesComponent from "@/components/superAdmin/FeaturesComponent";

export default function Features() {
  return <FeaturesComponent />
}