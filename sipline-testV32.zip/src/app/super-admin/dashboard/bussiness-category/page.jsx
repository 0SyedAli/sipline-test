import BussinessCategory from '@/components/superAdmin/BussinessCategory'
import React from 'react'

const BussinessCategoryPage = () => {
  return (
    <BussinessCategory />
  )
}

export default BussinessCategoryPage