import DashboardPanel from "./dashboard-panel/page";

export default function Dashboard() {
  return (
    <>
    <DashboardPanel />
    </>
  );
}
