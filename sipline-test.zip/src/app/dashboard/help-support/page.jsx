import React from "react";

const HelpSupport = () => {
  return (
    <div className="page">
      <div className="dash_head2">
        <h3>Help & Support</h3>
      </div>
      <div className="privacy_policy">
        <div className="pp_item">
          <h3>Lorem ipsum dolor sit amet</h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. In commodo
            est et nunc blandit, sit amet sagittis tortor aliquam. Morbi metus
            ipsum, tincidunt non leo vitae, pulvinar venenatis tortor.
            Suspendisse aliquet leo erat, in luctus massa porta ac. Vivamus nec
            sapien eget ante vehicula convallis eget ut lectus. Fusce congue
            rhoncus nibh a vulputate. In tempus purus vitae ipsum sollicitudin
            vehicula ac ut nibh. Aliquam erat volutpat. Cras scelerisque purus
            ac lacinia consectetur. Integer vulputate feugiat nisl. Sed quis
            arcu eros. Suspendisse suscipit massa est, in commodo quam
            scelerisque in. Praesent euismod, nisl vel egestas lacinia, nibh
            neque ornare nulla, et efficitur ipsum tortor nec erat. Aliquam
            felis massa, consequat ac eleifend a, dictum sed magna. Suspendisse
            potenti. Integer quis lectus at est dictum mollis nec sodales
            tortor.
          </p>
        </div>
        <div className="pp_item">
          <h3>Lorem ipsum dolor sit amet</h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. In commodo
            est et nunc blandit, sit amet sagittis tortor aliquam. Morbi metus
            ipsum, tincidunt non leo vitae, pulvinar venenatis tortor.
            Suspendisse aliquet leo erat, in luctus massa porta ac. Vivamus nec
            sapien eget ante vehicula convallis eget ut lectus. Fusce congue
            rhoncus nibh a vulputate. In tempus purus vitae ipsum sollicitudin
            vehicula ac ut nibh. Aliquam erat volutpat. Cras scelerisque purus
            ac lacinia consectetur. Integer vulputate feugiat nisl. Sed quis
            arcu eros. Suspendisse suscipit massa est, in commodo quam
            scelerisque in. Praesent euismod, nisl vel egestas lacinia, nibh
            neque ornare nulla, et efficitur ipsum tortor nec erat. Aliquam
            felis massa, consequat ac eleifend a, dictum sed magna. Suspendisse
            potenti. Integer quis lectus at est dictum mollis nec sodales
            tortor.
          </p>
        </div>
        <div className="pp_item">
          <h3>Lorem ipsum dolor sit amet</h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. In commodo
            est et nunc blandit, sit amet sagittis tortor aliquam. Morbi metus
            ipsum, tincidunt non leo vitae, pulvinar venenatis tortor.
            Suspendisse aliquet leo erat, in luctus massa porta ac. Vivamus nec
            sapien eget ante vehicula convallis eget ut lectus. Fusce congue
            rhoncus nibh a vulputate. In tempus purus vitae ipsum sollicitudin
            vehicula ac ut nibh. Aliquam erat volutpat. Cras scelerisque purus
            ac lacinia consectetur. Integer vulputate feugiat nisl. Sed quis
            arcu eros. Suspendisse suscipit massa est, in commodo quam
            scelerisque in. Praesent euismod, nisl vel egestas lacinia, nibh
            neque ornare nulla, et efficitur ipsum tortor nec erat. Aliquam
            felis massa, consequat ac eleifend a, dictum sed magna. Suspendisse
            potenti. Integer quis lectus at est dictum mollis nec sodales
            tortor.
          </p>
        </div>
        <div className="pp_item">
          <h3>Lorem ipsum dolor sit amet</h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. In commodo
            est et nunc blandit, sit amet sagittis tortor aliquam. Morbi metus
            ipsum, tincidunt non leo vitae, pulvinar venenatis tortor.
            Suspendisse aliquet leo erat, in luctus massa porta ac. Vivamus nec
            sapien eget ante vehicula convallis eget ut lectus. Fusce congue
            rhoncus nibh a vulputate. In tempus purus vitae ipsum sollicitudin
            vehicula ac ut nibh. Aliquam erat volutpat. Cras scelerisque purus
            ac lacinia consectetur. Integer vulputate feugiat nisl. Sed quis
            arcu eros. Suspendisse suscipit massa est, in commodo quam
            scelerisque in. Praesent euismod, nisl vel egestas lacinia, nibh
            neque ornare nulla, et efficitur ipsum tortor nec erat. Aliquam
            felis massa, consequat ac eleifend a, dictum sed magna. Suspendisse
            potenti. Integer quis lectus at est dictum mollis nec sodales
            tortor.
          </p>
        </div>
      </div>
    </div>
  );
};

export default HelpSupport;
